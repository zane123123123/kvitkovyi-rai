"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ArrowLeft, Plus, Edit, Trash2, Eye, EyeOff, Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"
import Link from "next/link"

interface Flower {
  id: string
  name: string
  type: string
  color: string
  price: number
  image: string
  description: string
}

interface FlowerForm {
  name: string
  type: string
  color: string
  price: string
  image: string
  description: string
}

interface Order {
  id: string
  name: string
  phone: string
  email: string
  address: string
  notes: string
  items: any[]
  total: number
  date: string
  status: string
}

interface Review {
  id: string
  name: string
  rating: number
  comment: string
  date: string
  approved: boolean
}

export default function AdminPanel() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loginForm, setLoginForm] = useState({ username: "", password: "" })
  const [showPassword, setShowPassword] = useState(false)
  const [flowers, setFlowers] = useState<Flower[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [reviews, setReviews] = useState<Review[]>([])
  const [isAddFlowerOpen, setIsAddFlowerOpen] = useState(false)
  const [isEditFlowerOpen, setIsEditFlowerOpen] = useState(false)
  const [editingFlower, setEditingFlower] = useState<Flower | null>(null)
  const [flowerForm, setFlowerForm] = useState<FlowerForm>({
    name: "",
    type: "",
    color: "",
    price: "",
    image: "",
    description: "",
  })
  const [activeTab, setActiveTab] = useState<"flowers" | "orders" | "reviews">("flowers")
  const [selectedFlowers, setSelectedFlowers] = useState<string[]>([])
  const [isImagePreviewOpen, setIsImagePreviewOpen] = useState(false)
  const [previewImage, setPreviewImage] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    // Check if already authenticated
    const authStatus = localStorage.getItem("adminAuth")
    if (authStatus === "true") {
      setIsAuthenticated(true)
      loadData()
    }
  }, [])

  const loadData = () => {
    const savedFlowers = localStorage.getItem("flowers")
    const savedOrders = localStorage.getItem("orders")
    const savedReviews = localStorage.getItem("globalReviews")

    if (savedFlowers) {
      setFlowers(JSON.parse(savedFlowers))
    }

    if (savedOrders) {
      setOrders(JSON.parse(savedOrders))
    }

    if (savedReviews) {
      setReviews(JSON.parse(savedReviews))
    }
  }

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (loginForm.username === "admin" && loginForm.password === "zxcyarik123") {
      setIsAuthenticated(true)
      localStorage.setItem("adminAuth", "true")
      loadData()
      toast({
        title: "Успішний вхід",
        description: "Ласкаво просимо в адмін-панель!",
      })
    } else {
      toast({
        title: "Помилка входу",
        description: "Неправильний логін або пароль",
        variant: "destructive",
      })
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    localStorage.removeItem("adminAuth")
    setLoginForm({ username: "", password: "" })
  }

  const handleAddFlower = (e: React.FormEvent) => {
    e.preventDefault()

    // Спрощена валідація
    if (!flowerForm.name.trim()) {
      toast({
        title: "Помилка",
        description: "Введіть назву квітки",
        variant: "destructive",
      })
      return
    }

    if (!flowerForm.type.trim()) {
      toast({
        title: "Помилка",
        description: "Введіть тип квітки",
        variant: "destructive",
      })
      return
    }

    if (!flowerForm.color.trim()) {
      toast({
        title: "Помилка",
        description: "Введіть колір квітки",
        variant: "destructive",
      })
      return
    }

    if (!flowerForm.price.trim() || isNaN(Number(flowerForm.price)) || Number(flowerForm.price) <= 0) {
      toast({
        title: "Помилка",
        description: "Введіть коректну ціну",
        variant: "destructive",
      })
      return
    }

    if (!flowerForm.image.trim()) {
      toast({
        title: "Помилка",
        description: "Введіть посилання на зображення",
        variant: "destructive",
      })
      return
    }

    if (!flowerForm.description.trim()) {
      toast({
        title: "Помилка",
        description: "Введіть опис квітки",
        variant: "destructive",
      })
      return
    }

    try {
      const newFlower = {
        id: Date.now().toString(),
        name: flowerForm.name.trim(),
        type: flowerForm.type.trim(),
        color: flowerForm.color.trim(),
        price: Number(flowerForm.price),
        image: flowerForm.image.trim(),
        description: flowerForm.description.trim(),
      }

      const updatedFlowers = [...flowers, newFlower]
      setFlowers(updatedFlowers)
      localStorage.setItem("flowers", JSON.stringify(updatedFlowers))

      // Очистити форму
      setFlowerForm({
        name: "",
        type: "",
        color: "",
        price: "",
        image: "",
        description: "",
      })

      setIsAddFlowerOpen(false)

      toast({
        title: "Успіх!",
        description: `Квітку "${newFlower.name}" успішно додано`,
      })
    } catch (error) {
      console.error("Помилка при додаванні квітки:", error)
      toast({
        title: "Помилка",
        description: "Не вдалося додати квітку. Спробуйте ще раз.",
        variant: "destructive",
      })
    }
  }

  const handleEditFlower = (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingFlower) return

    const updatedFlower: Flower = {
      ...editingFlower,
      name: flowerForm.name,
      type: flowerForm.type,
      color: flowerForm.color,
      price: Number.parseFloat(flowerForm.price),
      image: flowerForm.image,
      description: flowerForm.description,
    }

    const updatedFlowers = flowers.map((f) => (f.id === editingFlower.id ? updatedFlower : f))
    setFlowers(updatedFlowers)
    localStorage.setItem("flowers", JSON.stringify(updatedFlowers))

    setEditingFlower(null)
    setIsEditFlowerOpen(false)

    toast({
      title: "Квітку оновлено",
      description: "Інформацію про квітку успішно оновлено",
    })
  }

  const handleDeleteFlower = (id: string) => {
    const updatedFlowers = flowers.filter((f) => f.id !== id)
    setFlowers(updatedFlowers)
    localStorage.setItem("flowers", JSON.stringify(updatedFlowers))

    toast({
      title: "Квітку видалено",
      description: "Квітку успішно видалено з каталогу",
    })
  }

  const openEditDialog = (flower: Flower) => {
    setEditingFlower(flower)
    setFlowerForm({
      name: flower.name,
      type: flower.type,
      color: flower.color,
      price: flower.price.toString(),
      image: flower.image,
      description: flower.description,
    })
    setIsEditFlowerOpen(true)
  }

  const duplicateFlower = (flower: Flower) => {
    const duplicatedFlower: Flower = {
      ...flower,
      id: Date.now().toString(),
      name: `${flower.name} (копія)`,
    }

    const updatedFlowers = [...flowers, duplicatedFlower]
    setFlowers(updatedFlowers)
    localStorage.setItem("flowers", JSON.stringify(updatedFlowers))

    toast({
      title: "Квітку продубльовано",
      description: "Створено копію квітки для редагування",
    })
  }

  const handleBulkDelete = () => {
    const updatedFlowers = flowers.filter((f) => !selectedFlowers.includes(f.id))
    setFlowers(updatedFlowers)
    localStorage.setItem("flowers", JSON.stringify(updatedFlowers))
    setSelectedFlowers([])

    toast({
      title: "Квіти видалено",
      description: `Видалено ${selectedFlowers.length} квітів`,
    })
  }

  const toggleFlowerSelection = (flowerId: string) => {
    setSelectedFlowers((prev) => (prev.includes(flowerId) ? prev.filter((id) => id !== flowerId) : [...prev, flowerId]))
  }

  const selectAllFlowers = () => {
    setSelectedFlowers(flowers.map((f) => f.id))
  }

  const clearSelection = () => {
    setSelectedFlowers([])
  }

  // Функції для управління відгуками
  const approveReview = (id: string) => {
    const updatedReviews = reviews.map((review) => (review.id === id ? { ...review, approved: true } : review))
    setReviews(updatedReviews)
    localStorage.setItem("globalReviews", JSON.stringify(updatedReviews))

    toast({
      title: "Відгук схвалено",
      description: "Відгук тепер відображається на сайті",
    })
  }

  const rejectReview = (id: string) => {
    const updatedReviews = reviews.map((review) => (review.id === id ? { ...review, approved: false } : review))
    setReviews(updatedReviews)
    localStorage.setItem("globalReviews", JSON.stringify(updatedReviews))

    toast({
      title: "Відгук відхилено",
      description: "Відгук не буде відображатися на сайті",
    })
  }

  const deleteReview = (id: string) => {
    const updatedReviews = reviews.filter((review) => review.id !== id)
    setReviews(updatedReviews)
    localStorage.setItem("globalReviews", JSON.stringify(updatedReviews))

    toast({
      title: "Відгук видалено",
      description: "Відгук успішно видалено",
    })
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Вхід в адмін-панель</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="username">Логін</Label>
                <Input
                  id="username"
                  value={loginForm.username}
                  onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                  placeholder="admin"
                />
              </div>
              <div>
                <Label htmlFor="password">Пароль</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                    placeholder="Введіть пароль"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full">
                Увійти
              </Button>
              <div className="text-center">
                <Link href="/">
                  <Button variant="outline" className="w-full">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Повернутися до магазину
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Адмін-панель</h1>
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="outline">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  До магазину
                </Button>
              </Link>
              <Button variant="outline" onClick={handleLogout}>
                Вийти
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "flowers" | "orders" | "reviews")}>
          <TabsList className="mb-6">
            <TabsTrigger value="flowers">Управління квітами ({flowers.length})</TabsTrigger>
            <TabsTrigger value="orders">Замовлення ({orders.length})</TabsTrigger>
            <TabsTrigger value="reviews">Відгуки ({reviews.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="flowers">
            <div className="space-y-6">
              {/* Add Flower Button */}
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-4">
                  <h2 className="text-xl font-semibold">Каталог квітів</h2>
                  {selectedFlowers.length > 0 && (
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary">{selectedFlowers.length} обрано</Badge>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Видалити обрані
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Підтвердження видалення</AlertDialogTitle>
                            <AlertDialogDescription>
                              Ви впевнені, що хочете видалити {selectedFlowers.length} квітів? Цю дію неможливо
                              скасувати.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel onClick={clearSelection}>Скасувати</AlertDialogCancel>
                            <AlertDialogAction onClick={handleBulkDelete}>Видалити всі</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                      <Button variant="outline" size="sm" onClick={clearSelection}>
                        Скасувати вибір
                      </Button>
                    </div>
                  )}
                </div>

                <div className="flex items-center space-x-2">
                  {flowers.length > 0 && (
                    <Button
                      variant="outline"
                      onClick={selectedFlowers.length === flowers.length ? clearSelection : selectAllFlowers}
                    >
                      {selectedFlowers.length === flowers.length ? "Скасувати все" : "Обрати все"}
                    </Button>
                  )}
                  <Dialog open={isAddFlowerOpen} onOpenChange={setIsAddFlowerOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Додати квітку
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Додати нову квітку</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddFlower} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="addName">Назва *</Label>
                            <Input
                              id="addName"
                              value={flowerForm.name}
                              onChange={(e) => setFlowerForm({ ...flowerForm, name: e.target.value })}
                              placeholder="Назва квітки"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="addType">Тип *</Label>
                            <Input
                              id="addType"
                              value={flowerForm.type}
                              onChange={(e) => setFlowerForm({ ...flowerForm, type: e.target.value })}
                              placeholder="троянди, тюльпани, піони..."
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="addColor">Колір *</Label>
                            <Input
                              id="addColor"
                              value={flowerForm.color}
                              onChange={(e) => setFlowerForm({ ...flowerForm, color: e.target.value })}
                              placeholder="червоний, білий, рожевий..."
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="addPrice">Ціна (₴) *</Label>
                            <Input
                              id="addPrice"
                              type="number"
                              min="0"
                              step="0.01"
                              value={flowerForm.price}
                              onChange={(e) => setFlowerForm({ ...flowerForm, price: e.target.value })}
                              placeholder="150"
                              required
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="addImage">Посилання на зображення *</Label>
                          <Input
                            id="addImage"
                            value={flowerForm.image}
                            onChange={(e) => setFlowerForm({ ...flowerForm, image: e.target.value })}
                            placeholder="https://example.com/image.jpg або /placeholder.svg?height=300&width=300"
                            required
                          />
                        </div>
                        {flowerForm.image && (
                          <div className="mt-2">
                            <Label>Попередній перегляд:</Label>
                            <div className="mt-1 flex justify-center">
                              <Image
                                src={flowerForm.image || "/placeholder.svg"}
                                alt="Попередній перегляд"
                                width={200}
                                height={150}
                                className="rounded-lg object-cover border"
                                onError={(e) => {
                                  console.log("Помилка завантаження зображення")
                                }}
                              />
                            </div>
                          </div>
                        )}
                        <div>
                          <Label htmlFor="addDescription">Опис *</Label>
                          <Textarea
                            id="addDescription"
                            value={flowerForm.description}
                            onChange={(e) => setFlowerForm({ ...flowerForm, description: e.target.value })}
                            placeholder="Опис квітки"
                            rows={3}
                            required
                          />
                        </div>
                        <div className="flex space-x-2">
                          <Button type="submit" className="flex-1">
                            Додати квітку
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                              setFlowerForm({
                                name: "",
                                type: "",
                                color: "",
                                price: "",
                                image: "",
                                description: "",
                              })
                              setIsAddFlowerOpen(false)
                            }}
                          >
                            Скасувати
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              {/* Flowers Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {flowers.map((flower) => (
                  <Card key={flower.id} className="overflow-hidden">
                    <CardHeader className="p-0">
                      <div className="relative">
                        <Image
                          src={flower.image || "/placeholder.svg"}
                          alt={flower.name}
                          width={300}
                          height={200}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <Badge variant="secondary" className="bg-white/90">
                            {flower.color}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Badge variant="outline" className="text-xs">
                            {flower.type}
                          </Badge>
                          <input
                            type="checkbox"
                            checked={selectedFlowers.includes(flower.id)}
                            onChange={() => toggleFlowerSelection(flower.id)}
                            className="w-4 h-4"
                          />
                        </div>
                        <h3 className="font-semibold text-lg leading-tight">{flower.name}</h3>
                        <p className="text-sm text-muted-foreground">{flower.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-xl font-bold text-primary">{flower.price} ₴</span>
                          <div className="flex space-x-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setPreviewImage(flower.image)
                                setIsImagePreviewOpen(true)
                              }}
                              title="Переглянути зображення"
                            >
                              👁️
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => duplicateFlower(flower)}
                              title="Дублювати"
                            >
                              📋
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openEditDialog(flower)}
                              title="Редагувати"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" variant="outline" title="Видалити">
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Підтвердження видалення</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Ви впевнені, що хочете видалити "{flower.name}"? Цю дію неможливо скасувати.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Скасувати</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDeleteFlower(flower.id)}>
                                    Видалити
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {flowers.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-lg">Каталог порожній. Додайте першу квітку!</p>
                </div>
              )}

              {/* Edit Flower Dialog */}
              <Dialog open={isEditFlowerOpen} onOpenChange={setIsEditFlowerOpen}>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Редагувати квітку</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleEditFlower} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="editName">Назва *</Label>
                        <Input
                          id="editName"
                          value={flowerForm.name}
                          onChange={(e) => setFlowerForm({ ...flowerForm, name: e.target.value })}
                          placeholder="Назва квітки"
                        />
                      </div>
                      <div>
                        <Label htmlFor="editType">Тип *</Label>
                        <Input
                          id="editType"
                          value={flowerForm.type}
                          onChange={(e) => setFlowerForm({ ...flowerForm, type: e.target.value })}
                          placeholder="троянди, тюльпани, піони..."
                        />
                      </div>
                      <div>
                        <Label htmlFor="editColor">Колір *</Label>
                        <Input
                          id="editColor"
                          value={flowerForm.color}
                          onChange={(e) => setFlowerForm({ ...flowerForm, color: e.target.value })}
                          placeholder="червоний, білий, рожевий..."
                        />
                      </div>
                      <div>
                        <Label htmlFor="editPrice">Ціна (₴) *</Label>
                        <Input
                          id="editPrice"
                          type="number"
                          min="0"
                          step="0.01"
                          value={flowerForm.price}
                          onChange={(e) => setFlowerForm({ ...flowerForm, price: e.target.value })}
                          placeholder="150"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="editImage">Посилання на зображення *</Label>
                      <Input
                        id="editImage"
                        value={flowerForm.image}
                        onChange={(e) => setFlowerForm({ ...flowerForm, image: e.target.value })}
                        placeholder="https://example.com/image.jpg або /placeholder.svg?height=300&width=300"
                      />
                    </div>
                    {flowerForm.image && (
                      <div className="mt-2">
                        <Label>Попередній перегляд:</Label>
                        <div className="mt-1 flex justify-center">
                          <Image
                            src={flowerForm.image || "/placeholder.svg"}
                            alt="Попередній перегляд"
                            width={200}
                            height={150}
                            className="rounded-lg object-cover border"
                            onError={() => {
                              toast({
                                title: "Помилка завантаження зображення",
                                description: "Перевірте правильність посилання",
                                variant: "destructive",
                              })
                            }}
                          />
                        </div>
                      </div>
                    )}
                    <div>
                      <Label htmlFor="editDescription">Опис *</Label>
                      <Textarea
                        id="editDescription"
                        value={flowerForm.description}
                        onChange={(e) => setFlowerForm({ ...flowerForm, description: e.target.value })}
                        placeholder="Опис квітки"
                        rows={3}
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Зберегти зміни
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>

              {/* Image Preview Dialog */}
              <Dialog open={isImagePreviewOpen} onOpenChange={setIsImagePreviewOpen}>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Попередній перегляд зображення</DialogTitle>
                  </DialogHeader>
                  <div className="flex justify-center">
                    <Image
                      src={previewImage || "/placeholder.svg"}
                      alt="Попередній перегляд"
                      width={500}
                      height={400}
                      className="rounded-lg object-cover max-h-96"
                    />
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </TabsContent>

          <TabsContent value="orders">
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Замовлення клієнтів</h2>

              {orders.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-lg">Замовлень поки що немає</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <Card key={order.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">Замовлення #{order.id}</CardTitle>
                            <p className="text-sm text-muted-foreground">
                              {new Date(order.date).toLocaleDateString("uk-UA", {
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </p>
                          </div>
                          <Badge variant="secondary">{order.status}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <h4 className="font-semibold mb-2">Контактна інформація</h4>
                            <div className="space-y-1 text-sm">
                              <p>
                                <strong>Ім'я:</strong> {order.name}
                              </p>
                              <p>
                                <strong>Телефон:</strong> {order.phone}
                              </p>
                              <p>
                                <strong>Email:</strong> {order.email}
                              </p>
                              <p>
                                <strong>Адреса:</strong> {order.address}
                              </p>
                              {order.notes && (
                                <p>
                                  <strong>Примітки:</strong> {order.notes}
                                </p>
                              )}
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2">Товари ({order.items.length})</h4>
                            <div className="space-y-2">
                              {order.items.map((item, index) => (
                                <div key={index} className="flex justify-between text-sm">
                                  <span>
                                    {item.name} x{item.quantity}
                                  </span>
                                  <span>{item.price * item.quantity} ₴</span>
                                </div>
                              ))}
                              <div className="border-t pt-2 font-semibold">
                                <div className="flex justify-between">
                                  <span>Загалом:</span>
                                  <span>{order.total} ₴</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="reviews">
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Управління відгуками</h2>

              {reviews.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-lg">Відгуків поки що немає</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <Card key={review.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-pink-200 to-purple-200 flex items-center justify-center">
                              <span className="font-semibold text-pink-800">{review.name.charAt(0)}</span>
                            </div>
                            <div>
                              <h3 className="font-medium">{review.name}</h3>
                              <div className="flex items-center space-x-2">
                                <div className="flex">
                                  {Array.from({ length: 5 }).map((_, i) => (
                                    <span
                                      key={i}
                                      className={`text-sm ${i < review.rating ? "text-yellow-400" : "text-gray-300"}`}
                                    >
                                      ★
                                    </span>
                                  ))}
                                </div>
                                <span className="text-sm text-muted-foreground">({review.rating}/5)</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant={review.approved ? "default" : "secondary"}>
                              {review.approved ? "Схвалено" : "На розгляді"}
                            </Badge>
                            <span className="text-sm text-muted-foreground">{review.date}</span>
                          </div>
                        </div>

                        <p className="text-sm mb-4">{review.comment}</p>

                        <div className="flex items-center space-x-2">
                          {!review.approved && (
                            <Button
                              size="sm"
                              onClick={() => approveReview(review.id)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <Check className="w-4 h-4 mr-1" />
                              Схвалити
                            </Button>
                          )}
                          {review.approved && (
                            <Button size="sm" variant="outline" onClick={() => rejectReview(review.id)}>
                              <X className="w-4 h-4 mr-1" />
                              Відхилити
                            </Button>
                          )}
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="destructive">
                                <Trash2 className="w-4 h-4 mr-1" />
                                Видалити
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Підтвердження видалення</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Ви впевнені, що хочете видалити цей відгук? Цю дію неможливо скасувати.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Скасувати</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteReview(review.id)}>Видалити</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
