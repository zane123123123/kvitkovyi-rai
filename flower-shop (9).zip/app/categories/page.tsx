"use client"

import { useState, useEffect } from "react"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"

interface FlowerCategory {
  id: string
  name: string
  image: string
  description: string
  count: number
}

// Мапа для відповідності типів квітів до зображень категорій
const categoryImages: Record<string, string> = {
  троянди: "/images/categories/roses.jpg",
  тюльпани: "/images/categories/tulips.png",
  піони: "/images/categories/peonies.png",
  соняшники: "/images/categories/sunflowers.png",
  орхідеї: "/images/categories/orchids.png",
}

// Опис для кожної категорії
const categoryDescriptions: Record<string, string> = {
  троянди: "Елегантні троянди різних кольорів та сортів для будь-якого випадку",
  тюльпани: "Яскраві весняні тюльпани, що символізують оновлення та радість",
  піони: "Розкішні пишні піони з неперевершеним ароматом та красою",
  соняшники: "Сонячні та яскраві соняшники, що дарують тепло та позитив",
  орхідеї: "Витончені та елегантні орхідеї для особливих моментів",
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<FlowerCategory[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Завантаження квітів з localStorage
    const savedFlowers = localStorage.getItem("flowers")
    if (savedFlowers) {
      const flowers = JSON.parse(savedFlowers)

      // Групування квітів за типом
      const categoriesMap = flowers.reduce((acc: Record<string, any>, flower: any) => {
        if (!acc[flower.type]) {
          // Використовуємо зображення з нашої мапи категорій або зображення квітки, якщо категорія не знайдена
          const categoryImage = categoryImages[flower.type] || flower.image
          const categoryDescription = categoryDescriptions[flower.type] || `Колекція квітів типу "${flower.type}"`

          acc[flower.type] = {
            id: flower.type,
            name: flower.type.charAt(0).toUpperCase() + flower.type.slice(1),
            image: categoryImage,
            description: categoryDescription,
            count: 1,
          }
        } else {
          acc[flower.type].count += 1
        }
        return acc
      }, {})

      setCategories(Object.values(categoriesMap))
    }
    setLoading(false)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Interactive Logo */}
            <Link href="/" className="group">
              <div className="flex items-center space-x-3 px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                  <span className="text-white font-bold text-lg">🌸</span>
                </div>
                <h1 className="text-2xl font-bold text-white drop-shadow-sm">Квітковий рай</h1>
              </div>
            </Link>

            {/* Navigation */}
            <nav className="flex items-center space-x-2">
              <Link href="/">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Каталог
                </Button>
              </Link>
              <Link href="/categories">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Товари
                </Button>
              </Link>
              <Link href="/contacts">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Контакти
                </Button>
              </Link>
            </nav>

            <Link href="/">
              <Button variant="outline" className="hover:bg-pink-50 hover:border-pink-300 transition-colors">
                <ArrowLeft className="w-4 h-4 mr-2" />
                До каталогу
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-center">Категорії квітів</h1>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Завантаження категорій...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Link href={`/?type=${category.id}`} key={category.id}>
                <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full hover:scale-105 transition-transform duration-300">
                  <CardHeader className="p-0">
                    <div className="relative">
                      <Image
                        src={category.image || "/placeholder.svg?height=300&width=300"}
                        alt={category.name}
                        width={300}
                        height={200}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-end">
                        <div className="p-4 text-white">
                          <h3 className="text-xl font-bold">{category.name}</h3>
                          <p className="text-sm opacity-90">Переглянути колекцію</p>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-2">{category.name}</h2>
                    <p className="text-muted-foreground mb-4">{category.description}</p>
                    <p className="text-sm font-medium">
                      {category.count} {category.count === 1 ? "товар" : category.count < 5 ? "товари" : "товарів"}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}

        {categories.length === 0 && !loading && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">Категорії не знайдено</p>
            <Link href="/">
              <Button className="mt-4 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
                Перейти до каталогу
              </Button>
            </Link>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 Квітковий рай. Всі права захищені.</p>
            <p className="mt-2">Доставка свіжих квітів по всій Україні</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
