"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Phone, MapPin, Clock, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

export default function ContactsPage() {
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    message: "",
  })
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Валідація форми
    if (!contactForm.name || !contactForm.email || !contactForm.message) {
      toast({
        title: "Помилка",
        description: "Будь ласка, заповніть всі поля форми",
        variant: "destructive",
      })
      return
    }

    // Імітація відправки повідомлення
    toast({
      title: "Повідомлення надіслано",
      description: "Дякуємо за ваше звернення! Ми зв'яжемося з вами найближчим часом.",
    })

    // Очистка форми
    setContactForm({
      name: "",
      email: "",
      message: "",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Interactive Logo */}
            <Link href="/" className="group">
              <div className="flex items-center space-x-3 px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                  <span className="text-white font-bold text-lg">🌸</span>
                </div>
                <h1 className="text-2xl font-bold text-white drop-shadow-sm">Квітковий рай</h1>
              </div>
            </Link>

            {/* Navigation */}
            <nav className="flex items-center space-x-2">
              <Link href="/">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Каталог
                </Button>
              </Link>
              <Link href="/categories">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Товари
                </Button>
              </Link>
              <Link href="/contacts">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Контакти
                </Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-center">Контакти</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Контактна інформація */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Наші контакти</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Phone className="w-5 h-5 text-pink-600 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Телефон</h3>
                    <p className="text-muted-foreground">+380 (50) 123-45-67</p>
                    <p className="text-muted-foreground">+380 (67) 765-43-21</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Mail className="w-5 h-5 text-pink-600 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Email</h3>
                    <p className="text-muted-foreground">info@flower-shop.ua</p>
                    <p className="text-muted-foreground">support@flower-shop.ua</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-pink-600 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Адреса</h3>
                    <p className="text-muted-foreground">вул. Князя Острозького, 6</p>
                    <p className="text-muted-foreground">м. Тернопіль, 46001</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Clock className="w-5 h-5 text-pink-600 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Графік роботи</h3>
                    <p className="text-muted-foreground">Пн-Пт: 9:00 - 20:00</p>
                    <p className="text-muted-foreground">Сб-Нд: 10:00 - 18:00</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Як нас знайти</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2560.8234567890123!2d25.5947!3d49.5535!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x473036ed622c8c5d%3A0x8d4b2c5e6f7a8b9c!2z0LLRg9C7LiDQmtC90Y_Qt9GPINC-0YHRgtGA0L7Qt9GM0LrQvtCz0L4sIDYsINCi0LXRgNC90L7Qv9GW0LvRjCwg0KLQtdGA0L3QvtC_0ZbQu9GM0YHRjNC60LAg0L7QsdC70LDRgdGC0YwsIDQ2MDAwLCDQo9C60YDQsNGX0L3QsA!5e0!3m2!1suk!2sua!4v1234567890123!5m2!1suk!2sua"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Карта розташування магазину"
                  />
                </div>
                <div className="mt-4 p-3 bg-pink-50 rounded-md">
                  <p className="text-sm text-pink-800">
                    📍 Ми знаходимося в центрі Тернополя, поруч з головними торговими центрами та зупинками громадського
                    транспорту.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Форма зворотного зв'язку */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Напишіть нам</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Ваше ім'я</Label>
                    <Input
                      id="name"
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      placeholder="Введіть ваше ім'я"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="message">Повідомлення</Label>
                    <Textarea
                      id="message"
                      value={contactForm.message}
                      onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                      placeholder="Ваше повідомлення..."
                      rows={5}
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Надіслати повідомлення
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="mt-6 p-4 bg-white rounded-lg shadow-sm">
              <h3 className="font-semibold mb-2">Часті запитання</h3>
              <div className="space-y-3">
                <div>
                  <h4 className="font-medium">Як замовити квіти?</h4>
                  <p className="text-sm text-muted-foreground">
                    Виберіть квіти в каталозі, додайте їх у кошик та оформіть замовлення.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Як здійснюється доставка?</h4>
                  <p className="text-sm text-muted-foreground">
                    Доставка здійснюється кур'єром по Тернополю та поштою по всій Україні.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Чи можна повернути товар?</h4>
                  <p className="text-sm text-muted-foreground">
                    Повернення можливе протягом 24 годин у разі пошкодження товару.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 Квітковий рай. Всі права захищені.</p>
            <p className="mt-2">Доставка свіжих квітів по всій Україні</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
