"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ShoppingCart, Search, Filter, Star, Shield, MessageCircle, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"
import Link from "next/link"

interface Flower {
  id: string
  name: string
  type: string
  color: string
  price: number
  image: string
  description: string
}

interface CartItem extends Flower {
  quantity: number
}

interface Review {
  id: string
  name: string
  rating: number
  comment: string
  date: string
  approved: boolean
}

interface OrderForm {
  name: string
  phone: string
  email: string
  address: string
  notes: string
}

const initialFlowers: Flower[] = [
  {
    id: "1",
    name: "Червоні троянди 'Гранд Прі'",
    type: "троянди",
    color: "червоний",
    price: 1500,
    image: "/images/red-roses-grand-prix.jpg",
    description: "Класичні червоні троянди з оксамитовими пелюстками",
  },
  {
    id: "2",
    name: "Білі тюльпани 'Сніжна королева'",
    type: "тюльпани",
    color: "білий",
    price: 700,
    image: "/images/white-tulips-snow-queen.jpg",
    description: "Ніжні білі тюльпани для особливих моментів",
  },
  {
    id: "3",
    name: "Рожеві піони 'Сара Бернар'",
    type: "піони",
    color: "рожевий",
    price: 850,
    image: "/images/pink-peonies-sara-bernar.jpg",
    description: "Пишні рожеві піони з неперевершеним ароматом",
  },
  {
    id: "4",
    name: "Жовті соняшники 'Сонячний день'",
    type: "соняшники",
    color: "жовтий",
    price: 550,
    image: "/images/yellow-sunflowers-sunny-day.jpg",
    description: "Яскраві соняшники, що дарують радість",
  },
  {
    id: "5",
    name: "Троянда 'Червона королева'",
    type: "троянди",
    color: "червоний",
    price: 900,
    image: "/images/red-rose-queen.jpg",
    description: "Елегантна червона троянда з королівською красою",
  },
  {
    id: "6",
    name: "Орхідея 'Білий шовк'",
    type: "орхідеї",
    color: "білий",
    price: 770,
    image: "/images/white-orchid-silk.jpg",
    description: "Витончена біла орхідея з шовковистими пелюстками",
  },
  {
    id: "7",
    name: "Тюльпан 'Весняний настрій'",
    type: "тюльпани",
    color: "рожевий",
    price: 1300,
    image: "/images/pink-tulip-spring-mood.jpg",
    description: "Яскравий весняний тюльпан, що дарує гарний настрій",
  },
]

// Початкові відгуки для демонстрації
const initialReviews: Review[] = [
  {
    id: "1",
    name: "Марія Петренко",
    rating: 5,
    comment:
      "Чудові квіти! Замовляла букет троянд на день народження мами, всі були в захваті. Свіжі, гарно оформлені, доставка вчасно.",
    date: "2025-01-10",
    approved: true,
  },
  {
    id: "2",
    name: "Олександр Коваленко",
    rating: 4,
    comment:
      "Дуже задоволений якістю квітів та обслуговуванням. Єдиний мінус - трохи запізнилися з доставкою, але попередили про це заздалегідь.",
    date: "2025-01-08",
    approved: true,
  },
  {
    id: "3",
    name: "Ірина Мельник",
    rating: 5,
    comment: "Замовляла букет півоній. Квіти були свіжі, гарно упаковані. Дякую за чудовий сервіс!",
    date: "2025-01-05",
    approved: true,
  },
]

export default function FlowerShop() {
  const [flowers, setFlowers] = useState<Flower[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedType, setSelectedType] = useState("всі")
  const [sortBy, setSortBy] = useState("name")
  const [cart, setCart] = useState<CartItem[]>([])
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isOrderOpen, setIsOrderOpen] = useState(false)
  const [isReviewOpen, setIsReviewOpen] = useState(false)
  const [reviews, setReviews] = useState<Review[]>([])
  const [orderForm, setOrderForm] = useState<OrderForm>({
    name: "",
    phone: "",
    email: "",
    address: "",
    notes: "",
  })
  const [reviewForm, setReviewForm] = useState({
    name: "",
    rating: 5,
    comment: "",
  })
  const { toast } = useToast()

  // Load data from localStorage on component mount
  useEffect(() => {
    // Завжди використовуємо оновлений список квітів
    setFlowers(initialFlowers)
    localStorage.setItem("flowers", JSON.stringify(initialFlowers))

    const savedCart = localStorage.getItem("cart")
    const savedReviews = localStorage.getItem("globalReviews")

    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }

    if (savedReviews) {
      setReviews(JSON.parse(savedReviews))
    } else {
      // Встановлюємо початкові відгуки, якщо їх немає
      setReviews(initialReviews)
      localStorage.setItem("globalReviews", JSON.stringify(initialReviews))
    }
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart))
  }, [cart])

  // Save reviews to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("globalReviews", JSON.stringify(reviews))
  }, [reviews])

  const flowerTypes = ["всі", ...Array.from(new Set(flowers.map((f) => f.type)))]

  const filteredAndSortedFlowers = flowers
    .filter((flower) => {
      const matchesSearch =
        flower.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        flower.type.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesType = selectedType === "всі" || flower.type === selectedType
      return matchesSearch && matchesType
    })
    .sort((a, b) => {
      if (sortBy === "name") {
        return a.name.localeCompare(b.name)
      } else if (sortBy === "price-asc") {
        return a.price - b.price
      } else if (sortBy === "price-desc") {
        return b.price - a.price
      }
      return 0
    })

  const addToCart = (flower: Flower) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === flower.id)
      if (existingItem) {
        return prevCart.map((item) => (item.id === flower.id ? { ...item, quantity: item.quantity + 1 } : item))
      } else {
        return [...prevCart, { ...flower, quantity: 1 }]
      }
    })
    toast({
      title: "Додано до кошика",
      description: `${flower.name} додано до кошика`,
    })
  }

  const removeFromCart = (id: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      removeFromCart(id)
    } else {
      setCart((prevCart) => prevCart.map((item) => (item.id === id ? { ...item, quantity } : item)))
    }
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!orderForm.name || !orderForm.phone || !orderForm.email || !orderForm.address) {
      toast({
        title: "Помилка",
        description: "Будь ласка, заповніть всі обов'язкові поля",
        variant: "destructive",
      })
      return
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(orderForm.email)) {
      toast({
        title: "Помилка",
        description: "Введіть коректну електронну пошту",
        variant: "destructive",
      })
      return
    }

    // Phone validation
    const phoneRegex = /^[+]?[0-9\s\-$$$$]{10,}$/
    if (!phoneRegex.test(orderForm.phone)) {
      toast({
        title: "Помилка",
        description: "Введіть коректний номер телефону",
        variant: "destructive",
      })
      return
    }

    // Save order to localStorage
    const orders = JSON.parse(localStorage.getItem("orders") || "[]")
    const newOrder = {
      id: Date.now().toString(),
      ...orderForm,
      items: cart,
      total: getTotalPrice(),
      date: new Date().toISOString(),
      status: "в обробці",
    }
    orders.push(newOrder)
    localStorage.setItem("orders", JSON.stringify(orders))

    // Clear cart and form
    setCart([])
    setOrderForm({
      name: "",
      phone: "",
      email: "",
      address: "",
      notes: "",
    })
    setIsOrderOpen(false)
    setIsCartOpen(false)

    toast({
      title: "Замовлення оформлено!",
      description: "Ваше замовлення в обробці. Ми зв'яжемося з вами найближчим часом.",
    })
  }

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!reviewForm.name || !reviewForm.comment) {
      toast({
        title: "Помилка",
        description: "Будь ласка, заповніть всі поля",
        variant: "destructive",
      })
      return
    }

    const newReview: Review = {
      id: Date.now().toString(),
      name: reviewForm.name,
      rating: reviewForm.rating,
      comment: reviewForm.comment,
      date: new Date().toLocaleDateString("uk-UA"),
      approved: false, // Повертаємо потребу схвалення адміністратором
    }

    setReviews([newReview, ...reviews])
    setReviewForm({
      name: "",
      rating: 5,
      comment: "",
    })
    setIsReviewOpen(false)

    toast({
      title: "Дякуємо за відгук!",
      description: "Ваш відгук буде опубліковано після перевірки адміністратором.",
    })
  }

  // Показуємо всі схвалені відгуки (тепер всі автоматично схвалені)
  const approvedReviews = reviews.filter((review) => review.approved)

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Interactive Logo */}
            <Link href="/" className="group">
              <div className="flex items-center space-x-3 px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                  <span className="text-white font-bold text-lg">🌸</span>
                </div>
                <h1 className="text-2xl font-bold text-white drop-shadow-sm">Квітковий рай</h1>
              </div>
            </Link>

            {/* Navigation */}
            <nav className="flex items-center space-x-2">
              <Link href="/">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Каталог
                </Button>
              </Link>
              <Link href="/categories">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Товари
                </Button>
              </Link>
              <Link href="/contacts">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Контакти
                </Button>
              </Link>
              <Link href="/reviews">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Відгуки
                </Button>
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button
                  variant="outline"
                  size="sm"
                  className="hover:bg-pink-50 hover:border-pink-300 transition-colors"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Адмін-панель
                </Button>
              </Link>

              <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
                <SheetTrigger asChild>
                  <Button
                    variant="outline"
                    className="relative hover:bg-pink-50 hover:border-pink-300 transition-colors"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    {getTotalItems() > 0 && (
                      <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-gradient-to-r from-pink-500 to-purple-600">
                        {getTotalItems()}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent className="w-full sm:max-w-lg">
                  <SheetHeader>
                    <SheetTitle>Кошик покупок</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 space-y-4 flex-1 overflow-y-auto">
                    {cart.length === 0 ? (
                      <p className="text-muted-foreground text-center py-8">Кошик порожній</p>
                    ) : (
                      <>
                        {cart.map((item) => (
                          <div key={item.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              width={60}
                              height={60}
                              className="rounded-md object-cover"
                            />
                            <div className="flex-1">
                              <h4 className="font-medium text-sm">{item.name}</h4>
                              <p className="text-sm text-muted-foreground">{item.price} ₴</p>
                              <div className="flex items-center space-x-2 mt-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                >
                                  -
                                </Button>
                                <span className="text-sm">{item.quantity}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                >
                                  +
                                </Button>
                              </div>
                            </div>
                            <Button size="sm" variant="ghost" onClick={() => removeFromCart(item.id)}>
                              ×
                            </Button>
                          </div>
                        ))}
                        <div className="border-t pt-4 space-y-4">
                          <div className="flex justify-between items-center font-bold text-lg">
                            <span>Загалом:</span>
                            <span>{getTotalPrice()} ₴</span>
                          </div>
                          <Dialog open={isOrderOpen} onOpenChange={setIsOrderOpen}>
                            <DialogTrigger asChild>
                              <Button
                                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                                size="lg"
                              >
                                Оформити замовлення
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Оформлення замовлення</DialogTitle>
                              </DialogHeader>
                              <form onSubmit={handleOrderSubmit} className="space-y-4">
                                <div>
                                  <Label htmlFor="name">Ім'я *</Label>
                                  <Input
                                    id="name"
                                    value={orderForm.name}
                                    onChange={(e) => setOrderForm({ ...orderForm, name: e.target.value })}
                                    placeholder="Ваше ім'я"
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="phone">Телефон *</Label>
                                  <Input
                                    id="phone"
                                    value={orderForm.phone}
                                    onChange={(e) => setOrderForm({ ...orderForm, phone: e.target.value })}
                                    placeholder="+380XXXXXXXXX"
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="email">Email *</Label>
                                  <Input
                                    id="email"
                                    type="email"
                                    value={orderForm.email}
                                    onChange={(e) => setOrderForm({ ...orderForm, email: e.target.value })}
                                    placeholder="your@email.com"
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="address">Адреса доставки *</Label>
                                  <Textarea
                                    id="address"
                                    value={orderForm.address}
                                    onChange={(e) => setOrderForm({ ...orderForm, address: e.target.value })}
                                    placeholder="Повна адреса доставки"
                                    rows={3}
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="notes">Примітки</Label>
                                  <Textarea
                                    id="notes"
                                    value={orderForm.notes}
                                    onChange={(e) => setOrderForm({ ...orderForm, notes: e.target.value })}
                                    placeholder="Додаткові побажання"
                                    rows={2}
                                  />
                                </div>
                                <div className="border-t pt-4">
                                  <div className="flex justify-between items-center font-bold text-lg mb-4">
                                    <span>До сплати:</span>
                                    <span>{getTotalPrice()} ₴</span>
                                  </div>
                                  <Button
                                    type="submit"
                                    className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                                    size="lg"
                                  >
                                    Підтвердити замовлення
                                  </Button>
                                </div>
                              </form>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </>
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Filters */}
      <div className="container mx-auto px-4 py-6">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex items-center space-x-2 flex-1">
              <Search className="w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Пошук квітів за назвою або типом..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-muted-foreground" />
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Тип квітів" />
                </SelectTrigger>
                <SelectContent>
                  {flowerTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type.charAt(0).toUpperCase() + type.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Сортування" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">За назвою</SelectItem>
                  <SelectItem value="price-asc">За ціною ↑</SelectItem>
                  <SelectItem value="price-desc">За ціною ↓</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAndSortedFlowers.map((flower) => (
            <Card key={flower.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader className="p-0">
                <div className="relative">
                  <Image
                    src={flower.image || "/placeholder.svg"}
                    alt={flower.name}
                    width={300}
                    height={300}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge variant="secondary" className="bg-white/90">
                      {flower.color}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-4">
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs">
                    {flower.type}
                  </Badge>
                  <h3 className="font-semibold text-lg leading-tight">{flower.name}</h3>
                  <p className="text-sm text-muted-foreground">{flower.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary">{flower.price} ₴</span>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="p-4 pt-0">
                <Button
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                  onClick={() => addToCart(flower)}
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Додати в кошик
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {filteredAndSortedFlowers.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">За вашим запитом квіти не знайдено</p>
          </div>
        )}
      </div>

      {/* Відгуки клієнтів */}
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Відгуки наших клієнтів</h2>
            <div className="flex items-center space-x-2">
              <Dialog open={isReviewOpen} onOpenChange={setIsReviewOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Залишити відгук
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Залишити відгук</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleReviewSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="reviewName">Ваше ім'я *</Label>
                      <Input
                        id="reviewName"
                        value={reviewForm.name}
                        onChange={(e) => setReviewForm({ ...reviewForm, name: e.target.value })}
                        placeholder="Введіть ваше ім'я"
                      />
                    </div>
                    <div>
                      <Label htmlFor="rating">Оцінка</Label>
                      <Select
                        value={reviewForm.rating.toString()}
                        onValueChange={(value) => setReviewForm({ ...reviewForm, rating: Number.parseInt(value) })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[5, 4, 3, 2, 1].map((rating) => (
                            <SelectItem key={rating} value={rating.toString()}>
                              {"★".repeat(rating)} ({rating})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="comment">Ваш відгук *</Label>
                      <Textarea
                        id="comment"
                        value={reviewForm.comment}
                        onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                        placeholder="Поділіться вашими враженнями про наш магазин"
                        rows={4}
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      <Send className="w-4 h-4 mr-2" />
                      Надіслати відгук
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
              <Link href="/reviews">
                <Button variant="outline">Всі відгуки</Button>
              </Link>
            </div>
          </div>

          {approvedReviews.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Поки що немає відгуків. Будьте першим!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {approvedReviews.slice(0, 6).map((review) => (
                <Card key={review.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-pink-200 to-purple-200 flex items-center justify-center">
                          <span className="font-semibold text-pink-800 text-sm">{review.name.charAt(0)}</span>
                        </div>
                        <span className="font-medium text-sm">{review.name}</span>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground">{review.date}</span>
                    </div>
                    <p className="text-sm">{review.comment}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 Квітковий рай. Всі права захищені.</p>
            <p className="mt-2">Доставка свіжих квітів по всій Україні</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
