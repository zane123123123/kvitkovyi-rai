"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Star, MessageCircle, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

interface Review {
  id: string
  name: string
  rating: number
  comment: string
  date: string
  approved: boolean
}

// Початкові відгуки для демонстрації
const initialReviews: Review[] = [
  {
    id: "1",
    name: "Марія Петренко",
    rating: 5,
    comment:
      "Чудові квіти! Замовляла букет троянд на день народження мами, всі були в захваті. Свіжі, гарно оформлені, доставка вчасно.",
    date: "2025-01-10",
    approved: true,
  },
  {
    id: "2",
    name: "Олександр Коваленко",
    rating: 4,
    comment:
      "Дуже задоволений якістю квітів та обслуговуванням. Єдиний мінус - трохи запізнилися з доставкою, але попередили про це заздалегідь.",
    date: "2025-01-08",
    approved: true,
  },
  {
    id: "3",
    name: "Ірина Мельник",
    rating: 5,
    comment: "Замовляла букет півоній. Квіти були свіжі, гарно упаковані. Дякую за чудовий сервіс!",
    date: "2025-01-05",
    approved: true,
  },
]

export default function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>([])
  const [reviewForm, setReviewForm] = useState({
    name: "",
    rating: 5,
    comment: "",
  })
  const { toast } = useToast()

  useEffect(() => {
    // Завантаження відгуків з localStorage
    const savedReviews = localStorage.getItem("globalReviews")
    if (savedReviews) {
      setReviews(JSON.parse(savedReviews))
    } else {
      // Встановлюємо початкові відгуки, якщо їх немає
      setReviews(initialReviews)
      localStorage.setItem("globalReviews", JSON.stringify(initialReviews))
    }
  }, [])

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!reviewForm.name || !reviewForm.comment) {
      toast({
        title: "Помилка",
        description: "Будь ласка, заповніть всі поля",
        variant: "destructive",
      })
      return
    }

    const newReview: Review = {
      id: Date.now().toString(),
      name: reviewForm.name,
      rating: reviewForm.rating,
      comment: reviewForm.comment,
      date: new Date().toLocaleDateString("uk-UA"),
      approved: false, // Повертаємо потребу схвалення адміністратором
    }

    const updatedReviews = [newReview, ...reviews]
    setReviews(updatedReviews)
    localStorage.setItem("globalReviews", JSON.stringify(updatedReviews))

    setReviewForm({
      name: "",
      rating: 5,
      comment: "",
    })

    toast({
      title: "Дякуємо за відгук!",
      description: "Ваш відгук буде опубліковано після перевірки адміністратором.",
    })
  }

  // Показуємо всі схвалені відгуки (тепер всі автоматично схвалені)
  const approvedReviews = reviews.filter((review) => review.approved)

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Interactive Logo */}
            <Link href="/" className="group">
              <div className="flex items-center space-x-3 px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                  <span className="text-white font-bold text-lg">🌸</span>
                </div>
                <h1 className="text-2xl font-bold text-white drop-shadow-sm">Квітковий рай</h1>
              </div>
            </Link>

            {/* Navigation */}
            <nav className="flex items-center space-x-2">
              <Link href="/">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Каталог
                </Button>
              </Link>
              <Link href="/categories">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Товари
                </Button>
              </Link>
              <Link href="/contacts">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Контакти
                </Button>
              </Link>
              <Link href="/reviews">
                <Button variant="ghost" className="hover:bg-pink-50 hover:text-pink-700 transition-colors">
                  Відгуки
                </Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-center">Відгуки наших клієнтів</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Форма для додавання відгуку */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Залишити відгук
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="reviewName">Ваше ім'я *</Label>
                    <Input
                      id="reviewName"
                      value={reviewForm.name}
                      onChange={(e) => setReviewForm({ ...reviewForm, name: e.target.value })}
                      placeholder="Введіть ваше ім'я"
                    />
                  </div>
                  <div>
                    <Label htmlFor="rating">Оцінка</Label>
                    <Select
                      value={reviewForm.rating.toString()}
                      onValueChange={(value) => setReviewForm({ ...reviewForm, rating: Number.parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[5, 4, 3, 2, 1].map((rating) => (
                          <SelectItem key={rating} value={rating.toString()}>
                            {"★".repeat(rating)} ({rating})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="comment">Ваш відгук *</Label>
                    <Textarea
                      id="comment"
                      value={reviewForm.comment}
                      onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                      placeholder="Поділіться вашими враженнями про наш магазин"
                      rows={4}
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    <Send className="w-4 h-4 mr-2" />
                    Надіслати відгук
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="mt-6 p-4 bg-white rounded-lg shadow-sm">
              <h3 className="font-semibold mb-2">Чому важливі ваші відгуки</h3>
              <p className="text-sm text-muted-foreground">
                Ваші відгуки допомагають нам покращувати наш сервіс та якість обслуговування. Ми цінуємо кожну думку і
                враховуємо всі побажання наших клієнтів.
              </p>
            </div>
          </div>

          {/* Список відгуків */}
          <div className="lg:col-span-2">
            <div className="space-y-4">
              {approvedReviews.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                  <p className="text-muted-foreground">Поки що немає відгуків. Будьте першим!</p>
                </div>
              ) : (
                approvedReviews.map((review) => (
                  <Card key={review.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-pink-200 to-purple-200 flex items-center justify-center">
                            <span className="font-semibold text-pink-800">{review.name.charAt(0)}</span>
                          </div>
                          <span className="font-medium">{review.name}</span>
                          <div className="flex">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <span className="text-sm text-muted-foreground">{review.date}</span>
                      </div>
                      <p className="text-sm">{review.comment}</p>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 Квітковий рай. Всі права захищені.</p>
            <p className="mt-2">Доставка свіжих квітів по всій Україні</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
